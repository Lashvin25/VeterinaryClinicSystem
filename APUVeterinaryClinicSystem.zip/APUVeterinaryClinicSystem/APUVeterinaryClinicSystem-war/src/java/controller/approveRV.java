/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyReceptionist;
import Model.MyReceptionistFacade;
import Model.MyUser;
import Model.MyUserFacade;
import Model.MyUserRegister;
import Model.MyUserRegisterFacade;
import Model.MyVet;
import Model.MyVetFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "approveRV", urlPatterns = {"/approveRV"})
public class approveRV extends HttpServlet {

    @EJB
    private MyReceptionistFacade myReceptionistFacade;

    @EJB
    private MyVetFacade myVetFacade;

    @EJB
    private MyUserFacade myUserFacade;

    @EJB
    private MyUserRegisterFacade myUserRegisterFacade;


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String TPnumber = request.getParameter("id");
        int number = 0; // Default value in case conversion fails

        try (PrintWriter out = response.getWriter()) {
            try {
                // Fetch existing user and staff details
                MyUserRegister registeredUser = myUserRegisterFacade.find(TPnumber);

                if (registeredUser == null){
                    throw new Exception();
                }
                
                String email = registeredUser.getEmail();
                String expertise1 = registeredUser.getExpertise1();
                String expertise2 = registeredUser.getExpertise2();
                String expertise3 = registeredUser.getExpertise3();
                String name = registeredUser.getName();
                number = registeredUser.getNumber();
                String password = registeredUser.getPassword();
                String status = registeredUser.getStatus();
                String userrole = registeredUser.getUserrole();
                String newStatus = "Approved";
                
                //Check user role and register accordingly
                if ("Vet".toUpperCase().equals(userrole.toUpperCase())) {
                    myUserFacade.create(new MyUser(TPnumber, name, password, userrole, number, email));
                    myVetFacade.create(new MyVet(TPnumber, name, password, email, number, expertise1, expertise2, expertise3));
                    myUserRegisterFacade.remove(registeredUser);
                    request.getRequestDispatcher("managerManageRVApprove.jsp").include(request, response);
                    out.println("<script>alert('Successfully Approved for Vet');</script>");
                } else if ("Receptionist".toUpperCase().equals(userrole.toUpperCase())) {
                    myUserFacade.create(new MyUser(TPnumber, name, password, userrole, number, email));
                    myReceptionistFacade.create(new MyReceptionist(TPnumber, name, password, email, number));
                    myUserRegisterFacade.remove(registeredUser);
                    request.getRequestDispatcher("managerManageRVApprove.jsp").include(request, response);
                    out.println("<script>alert('Successfully Approved for Receptionist');</script>");
                }


                // Remove user from MyUserRegister
                //myUserRegisterFacade.remove(registeredUser);
            
                //myUserFacade.create(new MyUser(TPnumber,name,password,userrole,number,email));
                //myReceptionistFacade.create(new MyReceptionist(TPnumber,name,password,email,number));
                //myVetFacade.create(new MyVet(TPnumber, name, password, email, number, expertise1, expertise2, expertise3));
                
            } catch (NumberFormatException e) {
                out.println("<script>alert('Invalid number format!');</script>");
            } catch (Exception e) {
                request.getRequestDispatcher("managerManageRVApprove.jsp").include(request, response);
                out.println("<script>alert('Sorry, Approve failed. Try again.');</script>");
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
