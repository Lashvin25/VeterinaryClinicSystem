/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyReceptionist;
import Model.MyReceptionistFacade;
import Model.MyUser;
import Model.MyUserFacade;
import Model.MyVet;
import Model.MyVetFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "deleteRV", urlPatterns = {"/deleteRV"})
public class deleteRV extends HttpServlet {

    @EJB
    private MyVetFacade myVetFacade;

    @EJB
    private MyUserFacade myUserFacade;

    @EJB
    private MyReceptionistFacade myReceptionistFacade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("id");
        try (PrintWriter out = response.getWriter()) {
            try {
                // Fetch existing user and staff details
                MyVet search = myVetFacade.find(username);
                MyReceptionist search1 = myReceptionistFacade.find(username);
                MyUser search3 = myUserFacade.find(username);

                if (search == null && search1 == null) {
                    out.println("<script>alert('Username not found in either MyVet or MyReceptionist databases.');</script>");
                    throw new Exception();
                }
                
                if (search1 != null) {
                    // Delete MyReceptionist database
                    
                    myReceptionistFacade.remove(search1);

                    // Delete MyUser database
                    
                    myUserFacade.remove(search3);

                    request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
                    out.println("<script>alert('" + username + ", Delete has been completed');</script>");
                } else if (search != null) {
                    
                    // Delete MyVet database
                    myVetFacade.remove(search);

                    // Delete MyUser database
                    myUserFacade.remove(search3);
                    request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
                    out.println("<script>alert('" + username + ", Delete has been completed');</script>");
                } else {
                    // Handle case where neither MyVet nor MyReceptionist is found
                    request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
                    out.println("<script>alert('No record found for " + username + "');</script>");
                }
            } catch (Exception e) {
                request.getRequestDispatcher("managerManageStaff.jsp").include(request, response);
                out.println("<script>alert('Sorry, deletion failed. Try again.');</script>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
