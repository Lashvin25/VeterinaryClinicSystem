/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyUser;
import Model.MyUserFacade;
import Model.MyVet;
import Model.MyVetFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "login", urlPatterns = {"/login"})
public class login extends HttpServlet {

    @EJB
    private MyVetFacade myVetFacade;

    @EJB
    private MyUserFacade myUserFacade;

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        
        try (PrintWriter out = response.getWriter()) {
            try{
                MyUser found = myUserFacade.find(username);
                MyVet find = myVetFacade.find(username);
                if (found == null){
                    throw new Exception();
                }
                if (!password.equals(found.getPassword())){
                    throw new Exception();
                }
                HttpSession a = request.getSession();
                a.setAttribute("user",username);
                HttpSession b = request.getSession();
                b.setAttribute("found",found);
                String UserRole = found.getUserrole();
                HttpSession vett = request.getSession();
                vett.setAttribute("vetList",find);
                if ("Manager".equals(UserRole)){
                    request.getRequestDispatcher("managerDashboard.jsp").include(request, response);
                }
                if ("Vet".equals(UserRole)){
                    
                    request.getRequestDispatcher("vetDashboard.jsp").include(request, response);
                }
                if ("Receptionist".equals(UserRole)){
                    request.getRequestDispatcher("receptionistDashboard.jsp").include(request, response);
                }
            }catch(Exception e){
                request.getRequestDispatcher("login.jsp").include(request, response);
                out.println("<script>alert('Kindly check your credentials. If you are new, wait for your registration to be approved.');</script>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
