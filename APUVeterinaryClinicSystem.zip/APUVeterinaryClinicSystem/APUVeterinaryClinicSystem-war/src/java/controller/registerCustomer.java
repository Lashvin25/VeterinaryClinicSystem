/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;


import Model.MyCustomer;
import Model.MyCustomerFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "registerCustomer", urlPatterns = {"/registerCustomer"})
public class registerCustomer extends HttpServlet {

    @EJB
    private MyCustomerFacade myCustomerFacade;

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String numberStr = request.getParameter("number");
        String gender = request.getParameter("gender");
        String ageStr = request.getParameter("age");
        int number = 0; // Default value in case conversion fails
        int age = 0;
        

        try (PrintWriter out = response.getWriter()) {
            try {
                MyCustomer search = myCustomerFacade.find(username);
                if (search != null ) {
                    throw new Exception();
                }
                // Validate username format
                if (!validateUsername(username)) {
                    throw new IllegalArgumentException("Invalid Customer Number format");
                }
            

                // Convert number to integer
                if (numberStr != null && !numberStr.isEmpty()) {
                    number = Integer.parseInt(numberStr);
                }
                
                if (ageStr != null && !ageStr.isEmpty()) {
                    age = Integer.parseInt(ageStr);
                }

                // Registration process
                myCustomerFacade.create(new MyCustomer(username,name,email,number,gender,age));
                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
                out.println("<script>alert('Your registeration was succesfully');</script>");
            } catch (NumberFormatException e) {
                out.println("<script>alert('Invalid number format!');</script>");
            } catch (IllegalArgumentException e) {
                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
                out.println("<script>alert('Invalid Customer Number format');</script>");
            } catch (Exception e) {
                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
                out.println("<script>alert('Sorry, try again');</script>");
            }
        }
    }
    // Method to validate username format
    private boolean validateUsername(String username) {
        // Define the pattern for "CUS" followed by exactly 6 digits
        String usernamePattern = "CUS\\d{6}";
        return username.matches(usernamePattern);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
