/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyCustomer;
import Model.MyCustomerFacade;
import Model.MyPet;
import Model.MyPetFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "searchCusPet", urlPatterns = {"/searchCusPet"})
public class searchCusPet extends HttpServlet {

    @EJB
    private MyCustomerFacade myCustomerFacade;

    @EJB
    private MyPetFacade myPetFacade;

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String ID = request.getParameter("searchID");
//        try (PrintWriter out = response.getWriter()) {
//            MyPet searchPet = myPetFacade.find(ID);
//            MyCustomer findCustomer = myCustomerFacade.find(ID);
//            if (searchPet != null && searchPet.getId().equals(ID)) {
//                request.setAttribute("petDetails", searchPet); // Setting the pet object in request
//                request.getRequestDispatcher("searchPet.jsp").include(request, response);
//                // Displaying Pet details
//                out.println("<h2>Pet Details:</h2>");
//                out.println("<p>ID: " + searchPet.getId() + "</p>");
//                out.println("<p>Name: " + searchPet.getName() + "</p>");
//                out.println("<p>Customer ID: " + searchPet.getCustomerId() + "</p>");
//                out.println("<p>Type: " + searchPet.getType() + "</p>");
//                out.println("<p>Sex: " + searchPet.getSex() + "</p>");
//                out.println("<p>Description: " + searchPet.getDescription() + "</p>");
//            } else if (findCustomer != null && findCustomer.getId().equals(ID)) {
//                request.setAttribute("customerDetails", findCustomer); // Setting the customer object in request
//                request.getRequestDispatcher("searchCustomer.jsp").include(request, response);
//
//                // Displaying Customer details
//                out.println("<h2>Customer Details:</h2>");
//                out.println("<p>Customer ID: " + findCustomer.getId() + "</p>");
//                out.println("<p>Name: " + findCustomer.getName() + "</p>");
//            } else {
//                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
//                out.println("<script>alert('ID does not exist, please try again.');</script>");
//            }
//        }
        try (PrintWriter out = response.getWriter()) {
        MyPet searchPet = myPetFacade.find(ID);
        MyCustomer findCustomer = myCustomerFacade.find(ID);
        if (searchPet != null && searchPet.getId().equals(ID)) {
            request.setAttribute("petDetails", searchPet);
            request.getRequestDispatcher("searchPet.jsp").forward(request, response);
        } else if (findCustomer != null && findCustomer.getId().equals(ID)) {
            request.setAttribute("customerDetails", findCustomer);
            request.getRequestDispatcher("searchCustomer.jsp").forward(request, response);
        } else {
            request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
            out.println("<script>alert('ID does not exist, please try again.');</script>");
        }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
