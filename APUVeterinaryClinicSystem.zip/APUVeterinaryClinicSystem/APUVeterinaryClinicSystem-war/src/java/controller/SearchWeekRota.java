/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyVet;
import Model.MyVetFacade;
import Model.WeeklyRota;
import Model.WeeklyRotaFacade;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "SearchWeekRota", urlPatterns = {"/SearchWeekRota"})
public class SearchWeekRota extends HttpServlet {

    @EJB
    private WeeklyRotaFacade weeklyRotaFacade;

    @EJB
    private MyVetFacade myVetFacade;
    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
    response.setContentType("text/html;charset=UTF-8");
    String sundaySelect = request.getParameter("sundaySelect");
    try (PrintWriter out = response.getWriter()) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        try {
            Date selectedDate = sdf.parse(sundaySelect);

            // Set calendar to the selected date
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(selectedDate);

            // Adjust the calendar to the previous Monday
            while (calendar.get(Calendar.DAY_OF_WEEK) != Calendar.MONDAY) {
                calendar.add(Calendar.DAY_OF_MONTH, -1);
            }
            Date startDate = calendar.getTime();

            // Adjust the calendar to the next Sunday
            calendar.add(Calendar.DAY_OF_MONTH, 6); // Adding 6 days to reach Sunday
            Date endDate = calendar.getTime();

            List<WeeklyRota> weeklyRotaDetailsList = new ArrayList<>();
            // Perform the search in the facade
            List<WeeklyRota> weeklyRotaList = weeklyRotaFacade.findAll();

            // Filter rows within the date range
            for (WeeklyRota weeklyRota : weeklyRotaList) {
                Date rotaDate = sdf.parse(weeklyRota.getId());
                if (!rotaDate.before(startDate) && !rotaDate.after(endDate)) {
                    WeeklyRota details = new WeeklyRota(
                            weeklyRota.getId(),
                            weeklyRota.getSlot1(),
                            weeklyRota.getSlot2(),
                            weeklyRota.getSlot3(),
                            weeklyRota.getSlot4(),
                            weeklyRota.getSlot5(),
                            weeklyRota.getSlot6(),
                            weeklyRota.getAvailable1(),
                            weeklyRota.getAvailable2(),
                            weeklyRota.getAvailable3(),
                            weeklyRota.getAvailable4(),
                            weeklyRota.getAvailable5(),
                            weeklyRota.getAvailable6()
                    );
                    weeklyRotaDetailsList.add(weeklyRota);
                }
            }

            if (!weeklyRotaDetailsList.isEmpty()) {
                List<MyVet> allVetss = myVetFacade.findAll();
                request.getSession().setAttribute("listofVets", allVetss);
                request.getSession().setAttribute("RotaDetails", weeklyRotaDetailsList);
                request.getRequestDispatcher("updateWeeklyRota.jsp").include(request, response);
            } else {
                // Redirect if the date range is not found
                List<MyVet> allVets = myVetFacade.findAll();
                request.setAttribute("vetList", allVets);
                request.setAttribute("selectedDate", sdf.format(startDate));
                request.getRequestDispatcher("createWeeklyRota.jsp").include(request, response);
            }

        } catch (Exception e) {
            out.println("Error parsing date: " + e.getMessage());
        }
    }
}



    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
