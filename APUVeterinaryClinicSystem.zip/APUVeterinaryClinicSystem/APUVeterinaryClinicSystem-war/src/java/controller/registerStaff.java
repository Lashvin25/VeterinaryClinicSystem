/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyStaff;
import Model.MyStaffFacade;
import Model.MyUser;
import Model.MyUserFacade;
import Model.MyUserRegister;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "registerStaff", urlPatterns = {"/registerStaff"})
public class registerStaff extends HttpServlet {

    @EJB
    private MyStaffFacade myStaffFacade;

    @EJB
    private MyUserFacade myUserFacade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("cpassword");
        String role = "Manager";
        String email = request.getParameter("email");
        String numberStr = request.getParameter("number");
        int number = 0; // Default value in case conversion fails
        

        try (PrintWriter out = response.getWriter()) {
            try {
                MyUser search = myUserFacade.find(username);
                MyStaff found = myStaffFacade.find(username);
                
                // Validate username format
                if (!validateUsername(username)) {
                    throw new IllegalArgumentException("Invalid TP Number format");
                }
            
                if (search != null || found != null) {
                    throw new Exception();
                }
                if (!password.equals(confirmPassword)) {
                    throw new Exception();
                }

                // Convert number to integer
                if (numberStr != null && !numberStr.isEmpty()) {
                    number = Integer.parseInt(numberStr);
                }

                // Registration process
                myStaffFacade.create(new MyStaff(username, name, password,number,email));
                myUserFacade.create(new MyUser(username,name, password,role,number,email));
                
                request.getRequestDispatcher("managerManageStaff.jsp").include(request, response);
                out.println("<script>alert('Staff: " + name + ", have been register succesfully');</script>");
            } catch (NumberFormatException e) {
                out.println("<script>alert('Invalid number format!');</script>");
            } catch (IllegalArgumentException e) {
                request.getRequestDispatcher("managerManageStaff.jsp").include(request, response);
                out.println("<script>alert('Invalid TP Number format');</script>");
            } catch (Exception e) {
                request.getRequestDispatcher("managerManageStaff.jsp").include(request, response);
                out.println("<script>alert('Sorry, try again');</script>");
            }
        }
    }
    // Method to validate username format
    private boolean validateUsername(String username) {
        // Define the pattern for "TP" followed by exactly 6 digits
        String usernamePattern = "TP\\d{6}";
        return username.matches(usernamePattern);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
