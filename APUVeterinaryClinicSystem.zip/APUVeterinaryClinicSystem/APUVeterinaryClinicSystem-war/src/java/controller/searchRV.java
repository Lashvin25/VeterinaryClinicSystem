/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyReceptionist;
import Model.MyReceptionistFacade;
import Model.MyVet;
import Model.MyVetFacade;
import java.io.IOException;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "searchRV", urlPatterns = {"/searchRV"})
public class searchRV extends HttpServlet {

        @EJB
        private MyReceptionistFacade myReceptionistFacade;

        @EJB
        private MyVetFacade myVetFacade;

   

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException{
        response.setContentType("text/html;charset=UTF-8");
        String TPnumber = request.getParameter("id");
        MyReceptionist receptionist = myReceptionistFacade.find(TPnumber);
        MyVet vet = null;

        if (receptionist != null) {
            request.setAttribute("existingUser", receptionist);
            request.setAttribute("userType", "receptionist");
        } else {
            vet = myVetFacade.find(TPnumber);
            if (vet != null) {
                request.setAttribute("existingUser", vet);
                request.setAttribute("userType", "vet");
            } else {
                request.setAttribute("errorMessage", "No user found with TP Number: " + TPnumber);
            }
        }

        request.getRequestDispatcher("searchRV.jsp").forward(request, response);
    }

    // doPost method if needed
    // ...
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
