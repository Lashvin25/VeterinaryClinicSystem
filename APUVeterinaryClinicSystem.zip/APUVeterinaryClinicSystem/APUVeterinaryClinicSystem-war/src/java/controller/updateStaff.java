/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyStaff;
import Model.MyStaffFacade;
import Model.MyUser;
import Model.MyUserFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "updateStaff", urlPatterns = {"/updateStaff"})
public class updateStaff extends HttpServlet {

    @EJB
    private MyUserFacade myUserFacade;

    @EJB
    private MyStaffFacade myStaffFacade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("cpassword");
        String email = request.getParameter("email");
        String numberStr = request.getParameter("number");
        int number = 0; // Default value in case conversion fails

        try (PrintWriter out = response.getWriter()) {
            try {
                // Fetch existing user and staff details
                MyUser existingUser = myUserFacade.find(username);
                MyStaff existingStaff = myStaffFacade.find(username);

                if (existingUser == null || existingStaff == null) {
                    throw new Exception("User not found");
                }

                if (!password.equals(confirmPassword)) {
                    throw new Exception("Password confirmation does not match");
                }

                // Convert number to integer
                if (numberStr != null && !numberStr.isEmpty()) {
                    number = Integer.parseInt(numberStr);
                }

                // Update process
                existingStaff.setName(name);
                existingStaff.setPassword(password);
                existingStaff.setNumber(number);
                existingStaff.setEmail(email);

                existingUser.setName(name);
                existingUser.setPassword(password);
                existingUser.setNumber(number);
                existingUser.setEmail(email);

                myStaffFacade.edit(existingStaff);
                myUserFacade.edit(existingUser);

                request.getRequestDispatcher("managerManageStaff.jsp").include(request, response);
                out.println("<script>alert('Staff: " + name + ", has been updated successfully');</script>");
            } catch (NumberFormatException e) {
                out.println("<script>alert('Invalid number format!');</script>");
            } catch (Exception e) {
                request.getRequestDispatcher("managerManageStaff.jsp").include(request, response);
                out.println("<script>alert('Sorry, update failed. Try again.');</script>");
            }
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
