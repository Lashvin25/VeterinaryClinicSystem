/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyAppointment;
import Model.MyAppointmentFacade;
import Model.WeeklyRota;
import Model.WeeklyRotaFacade;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "bookAppointment", urlPatterns = {"/bookAppointment"})
public class bookAppointment extends HttpServlet {

    @EJB
    private WeeklyRotaFacade weeklyRotaFacade;

    @EJB
    private MyAppointmentFacade myAppointmentFacade;

   

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String petID = request.getParameter("PetID");
        String customerID = request.getParameter("CustomerID");
        String date = request.getParameter("Date");
        String slot1 = request.getParameter("Slot1");
        String slot2 = request.getParameter("Slot2");
        String slot3 = request.getParameter("Slot3");
        String slot4 = request.getParameter("Slot4");
        String slot5 = request.getParameter("Slot5");
        String slot6 = request.getParameter("Slot6");

        try (PrintWriter out = response.getWriter()) {
            if (slot1 != null && !slot1.isEmpty()) {
                    out.println("<script>alert('Slot 1: " + slot1 + "');</script>");
                    // Proceed with slot 1 data
                    myAppointmentFacade.create(new MyAppointment(petID, customerID, date, slot1, "Slot 1"));
                    
                    WeeklyRota search = weeklyRotaFacade.find(date);
                    search.setAvailable1("Booked");
                    weeklyRotaFacade.edit(search);
                    
                    out.println("<script>alert('Successful Book Appointment for Slot 1');</script>");
                    request.getRequestDispatcher("makeAppointment.jsp").include(request, response);
                }

                if (slot2 != null && !slot2.isEmpty()) {
                    out.println("<script>alert('Slot 2: " + slot2 + "');</script>");
                    // Proceed with slot 2 data
                    myAppointmentFacade.create(new MyAppointment(petID, customerID, date, slot2, "Slot 2"));
                    WeeklyRota search1 = weeklyRotaFacade.find(date);
                    search1.setAvailable2("Booked");
                    weeklyRotaFacade.edit(search1);
                    out.println("<script>alert('Successful Book Appointment for Slot 3');</script>");
                    request.getRequestDispatcher("makeAppointment.jsp").include(request, response);
                }
                if (slot3 != null && !slot3.isEmpty()) {
                    out.println("<script>alert('Slot 3: " + slot3 + "');</script>");
                    // Proceed with slot 3 data
                    myAppointmentFacade.create(new MyAppointment(petID, customerID, date, slot3, "Slot 3"));
                    WeeklyRota search3 = weeklyRotaFacade.find(date);
                    search3.setAvailable3("Booked");
                    weeklyRotaFacade.edit(search3);
                    
                    out.println("<script>alert('Successful Book Appointment for Slot 1');</script>");
                    request.getRequestDispatcher("makeAppointment.jsp").include(request, response);
                }

                if (slot4 != null && !slot4.isEmpty()) {
                    out.println("<script>alert('Slot 4: " + slot4 + "');</script>");
                    // Proceed with slot 4 data
                    myAppointmentFacade.create(new MyAppointment(petID, customerID, date, slot4, "Slot 4"));
                    
                    WeeklyRota search4 = weeklyRotaFacade.find(date);
                    search4.setAvailable4("Booked");
                    weeklyRotaFacade.edit(search4);
                    
                    out.println("<script>alert('Successful Book Appointment for Slot 4');</script>");
                    request.getRequestDispatcher("makeAppointment.jsp").include(request, response);
                }
                if (slot5 != null && !slot5.isEmpty()) {
                    out.println("<script>alert('Slot 5: " + slot5 + "');</script>");
                    // Proceed with slot 5 data
                    myAppointmentFacade.create(new MyAppointment(petID, customerID, date, slot1, "Slot 5"));
                    
                    WeeklyRota search5 = weeklyRotaFacade.find(date);
                    search5.setAvailable5("Booked");
                    weeklyRotaFacade.edit(search5);
                    
                    out.println("<script>alert('Successful Book Appointment for Slot 5');</script>");
                    request.getRequestDispatcher("makeAppointment.jsp").include(request, response);
                }

                if (slot6 != null && !slot6.isEmpty()) {
                    out.println("<script>alert('Slot 6: " + slot6 + "');</script>");
                    // Proceed with slot 6 data
                    myAppointmentFacade.create(new MyAppointment(petID, customerID, date, slot2, "Slot 6"));
                    WeeklyRota search6 = weeklyRotaFacade.find(date);
                    search6.setAvailable6("Booked");
                    weeklyRotaFacade.edit(search6);
                    out.println("<script>alert('Successful Book Appointment for Slot 6');</script>");
                    request.getRequestDispatcher("makeAppointment.jsp").include(request, response);
                }

                // If none of the slots have values, throw an exception
                if (slot1 == null || slot1.isEmpty() && slot2 == null || slot2.isEmpty() && slot3 == null || slot3.isEmpty() && slot4 == null || slot4.isEmpty() && slot5 == null || slot5.isEmpty() && slot6 == null || slot6.isEmpty()) {
                    throw new Exception("No slots were selected.");
                }
        }catch (Exception e) {
                out.println("<script>alert('Sorry, Try Again. " + e.getMessage() + "');</script>");
                request.getRequestDispatcher("receptionistDashboard.jsp").include(request, response);
            }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
