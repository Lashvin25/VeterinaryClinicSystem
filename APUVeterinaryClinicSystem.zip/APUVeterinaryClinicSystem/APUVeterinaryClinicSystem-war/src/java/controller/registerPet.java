/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyCustomer;
import Model.MyCustomerFacade;
import Model.MyPet;
import Model.MyPetFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "registerPet", urlPatterns = {"/registerPet"})
public class registerPet extends HttpServlet {

    @EJB
    private MyPetFacade myPetFacade;

    @EJB
    private MyCustomerFacade myCustomerFacade;

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("petID");
        String name = request.getParameter("petName");
        String customerID = request.getParameter("customerID");
        String type = request.getParameter("petType");
        String sex = request.getParameter("petSex");
        String desc = request.getParameter("petDescription");
        
        

        try (PrintWriter out = response.getWriter()) {
            try {
                MyPet search = myPetFacade.find(username);
                if (search != null ) {
                    throw new Exception();
                }
                
                MyCustomer find = myCustomerFacade.find(customerID);
                if (find == null ){
                   throw new Exception("Customer not found or ID mismatch.");                   
                }
                // Validate username format
                if (!validateUsername(username)) {
                    throw new IllegalArgumentException("Invalid PET Number format");
                }
                if (!validateCustomerUsername(customerID)) {
                    throw new IllegalArgumentException("Invalid CUS Number format");
                }
            

                // Registration process
                myPetFacade.create(new MyPet(username,customerID,name,type,sex,desc));
                
                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
                out.println("<script>alert('Pet: " + name + ", have been register succesfully');</script>");
            } catch (NumberFormatException e) {
                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
                out.println("<script>alert('Invalid number format!');</script>");
            } catch (IllegalArgumentException e) {
                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
                out.println("<script>alert('Invalid PET/CUSTOMER Number format');</script>");
            } catch (Exception e) {
                request.getRequestDispatcher("receptionistManageCP.jsp").include(request, response);
                out.println("<script>alert('Pet ID exsisted or Customer ID mismatch, Try Again.');</script>");
            }
        }
    }
    // Method to validate username format
    private boolean validateUsername(String username) {
        // Define the pattern for "PET" followed by exactly 6 digits
        String usernamePattern = "PET\\d{6}";
        return username.matches(usernamePattern);
    }
    
    private boolean validateCustomerUsername(String customerID) {
        // Define the pattern for "PET" followed by exactly 6 digits
        String customerPattern = "CUS\\d{6}";
        return customerID.matches(customerPattern);
    }
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
