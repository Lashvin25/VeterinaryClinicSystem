/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyUser;
import Model.MyUserFacade;
import Model.MyUserRegister;
import Model.MyUserRegisterFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "register", urlPatterns = {"/register"})
public class register extends HttpServlet {

    @EJB
    private MyUserRegisterFacade myUserRegisterFacade;

    @EJB
    private MyUserFacade myUserFacade;

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("cpassword");
        String role = request.getParameter("role");
        String email = request.getParameter("email");
        String numberStr = request.getParameter("number");
        int number = 0; // Default value in case conversion fails
        String status = "Pending";
        String NoExpertise = "NoExpertise";

        String expertise1 = request.getParameter("expertise1");
        String expertise2 = request.getParameter("expertise2");
        String expertise3 = request.getParameter("expertise3");

        expertise1 = (expertise1 == null || expertise1.isEmpty()) ? "Empty" : expertise1;
        expertise2 = (expertise2 == null || expertise2.isEmpty()) ? "Empty" : expertise2;
        expertise3 = (expertise3 == null || expertise3.isEmpty()) ? "Empty" : expertise3;

        try (PrintWriter out = response.getWriter()) {
            try {
                MyUser search = myUserFacade.find(username);
                MyUserRegister found = myUserRegisterFacade.find(username);
                
                // Validate username format
                if (!validateUsername(username)) {
                    throw new IllegalArgumentException("Invalid TP Number format");
                }
                
                if (search != null || found != null) {
                    throw new Exception();
                }
                if (!password.equals(confirmPassword)) {
                    throw new Exception();
                }
                if (numberStr != null && !numberStr.isEmpty()) {
                    // Validate contact number format
                    if (!validateContactNumber(numberStr)) {
                        throw new IllegalArgumentException("Invalid contact number format");
                    }
                    number = Integer.parseInt(numberStr);
                }
                if (expertise1 == null || expertise1.isEmpty()) {
                    expertise1 = "Empty";
                }
                if (expertise2 == null || expertise2.isEmpty()) {
                    expertise2 = "Empty";
                }
                if (expertise3 == null || expertise3.isEmpty()) {
                    expertise3 = "Empty";
                }

                // Validation based on role
                // Validation based on role
                if (role.equals("Receptionist")) {
                    expertise1 = NoExpertise; // Set expertise to NoExpertise for Receptionist
                    expertise2 = NoExpertise;
                    expertise3 = NoExpertise;
                } else if (role.equals("Vet")) {
                   
                } else {
                    throw new Exception("Invalid role specified");
                }
                // Validate email format
                if (email == null || email.isEmpty() || !validateEmail(email)) {
                    throw new IllegalArgumentException("Invalid email format");
                }


//                // Convert number to integer
//                if (numberStr != null && !numberStr.isEmpty()) {
//                    number = Integer.parseInt(numberStr);
//                }

                // Registration process
                 myUserRegisterFacade.create(new MyUserRegister(username, name, password, role, number, email, expertise1, expertise2, expertise3, status));
                
                request.getRequestDispatcher("login.jsp").include(request, response);
                out.println("<br><br><br>Hi " + username + ", registration has been completed! Please wait for the admin's approval!");
            } catch (NumberFormatException e) {
                out.println("<br><br><br>Sorry " + username + ", invalid number format!");
            } catch (IllegalArgumentException e) {
                request.getRequestDispatcher("managerManageStaff.jsp").include(request, response);
                out.println("<script>alert('Invalid TP Number format');</script>");
            }catch (Exception e) {
                request.getRequestDispatcher("register.jsp").include(request, response);
                out.println("<br><br><br>Sorry " + username + ", " + e.getMessage());
            }
        }

    }
    // Method to validate username format
    private boolean validateUsername(String username) {
        // Define the pattern for "TP" followed by exactly 6 digits
        String usernamePattern = "TP\\d{6}";
        return username.matches(usernamePattern);
    }
    // Method to validate contact number format
    private boolean validateContactNumber(String numberStr) {
        // Define the pattern for a contact number starting with "60" followed by exactly 9 digits
        String contactNumberPattern = "^60\\d{9}$";
        return numberStr.matches(contactNumberPattern);
    }
    // Method to validate email format
    private boolean validateEmail(String email) {
        // Define the pattern for a valid email address
        String emailPattern = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        return email.matches(emailPattern);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
