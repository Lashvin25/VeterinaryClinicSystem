/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyReceptionist;
import Model.MyReceptionistFacade;
import Model.MyUser;
import Model.MyUserFacade;
import Model.MyVet;
import Model.MyVetFacade;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "updateRV", urlPatterns = {"/updateRV"})
public class updateRV extends HttpServlet {

    @EJB
    private MyVetFacade myVetFacade;

    @EJB
    private MyReceptionistFacade myReceptionistFacade;

    @EJB
    private MyUserFacade myUserFacade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String username = request.getParameter("username");
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("cpassword");
        String email = request.getParameter("email");
        String numberStr = request.getParameter("number");
        int number = 0; // Default value in case conversion fails
        String NoExpertise = "NoExpertise";

        String expertise1 = request.getParameter("expertise1");
        String expertise2 = request.getParameter("expertise2");
        String expertise3 = request.getParameter("expertise3");
        

        expertise1 = (expertise1 == null || expertise1.isEmpty()) ? "Empty" : expertise1;
        expertise2 = (expertise2 == null || expertise2.isEmpty()) ? "Empty" : expertise2;
        expertise3 = (expertise3 == null || expertise3.isEmpty()) ? "Empty" : expertise3;

        try (PrintWriter out = response.getWriter()) {
            try {
               
                if (!password.equals(confirmPassword)) {
                    throw new Exception("Password and confirm password do not match.");
                }

                // Convert number to integer
                if (numberStr != null && !numberStr.isEmpty()) {
                    number = Integer.parseInt(numberStr);
                }

                // Find username in databases
                MyVet search = myVetFacade.find(username);
                MyReceptionist search1 = myReceptionistFacade.find(username);
                MyUser search3 = myUserFacade.find(username);
                
                if (search == null && search1 == null) {
                    throw new Exception("Username not found in either MyVet or MyReceptionist databases.");
                }

                // Replace empty expertise fields with default values
                if (expertise1 == null || expertise1.isEmpty()) {
                    expertise1 = "Empty";
                }
                if (expertise2 == null || expertise2.isEmpty()) {
                    expertise2 = "Empty";
                }
                if (expertise3 == null || expertise3.isEmpty()) {
                    expertise3 = "Empty";
                }
//                
//                if (search1 != null) {
//                    // Update MyReceptionist database
//                    search1.setName(name);
//                    search1.setPassword(password);
//                    search1.setNumber(number);
//                    search1.setEmail(email);
//                    myReceptionistFacade.edit(search1);
//                    // Update MyUser database
//                    search3.setName(name);
//                    search3.setPassword(password);
//                    search3.setNumber(number);
//                    search3.setEmail(email);
//                    myUserFacade.edit(search3);
//                    request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
//                    out.println("<script>alert('" + username + ", Update has been completed');</script>");
//                }

                if (search1 != null) {
                    // Update MyReceptionist database
                    search1.setName(name);
                    search1.setPassword(password);
                    search1.setNumber(number);
                    search1.setEmail(email);
                    myReceptionistFacade.edit(search1);

                    // Update MyUser database
                    search3.setName(name);
                    search3.setPassword(password);
                    search3.setNumber(number);
                    search3.setEmail(email);
                    myUserFacade.edit(search3);

                    request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
                    out.println("<script>alert('" + username + ", Update has been completed');</script>");
                } else if (search != null) {
                    if (expertise1 == null || expertise1.isEmpty() || "Empty".equals(expertise1)) {
                        throw new Exception("At least one expertise field must be filled for a Vet.");
                    }
                    // Update MyVet database
                    search.setName(name);
                    search.setPassword(password);
                    search.setNumber(number);
                    search.setEmail(email);
                    search.setExpertise1(expertise1);
                    search.setExpertise2(expertise2);
                    search.setExpertise3(expertise3);
                    myVetFacade.edit(search);

                    // Update MyUser database
                    search3.setName(name);
                    search3.setPassword(password);
                    search3.setNumber(number);
                    search3.setEmail(email);
                    myUserFacade.edit(search3);

                    request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
                    out.println("<script>alert('" + username + ", Update has been completed');</script>");
                } else {
                    // Handle case where neither MyVet nor MyReceptionist is found
                    request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
                    out.println("<script>alert('No record found for " + username + "');</script>");
                }
                
            } catch (NumberFormatException e) {
                out.println("<script>alert('Sorry " + username + ", invalid number format!');</script>");
            } catch (Exception e) {
                request.getRequestDispatcher("managerManageReceptionistVets.jsp").include(request, response);
                out.println("<script>alert('Sorry Try Again');</script>");
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
