/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyAppointment;
import Model.MyAppointmentFacade;
import Model.WeeklyRota;
import Model.WeeklyRotaFacade;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "deleteAppointmentID", urlPatterns = {"/deleteAppointmentID"})
public class deleteAppointmentID extends HttpServlet {

    @EJB
    private WeeklyRotaFacade weeklyRotaFacade;

    @EJB
    private MyAppointmentFacade myAppointmentFacade;

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String DeleteID = request.getParameter("appoint");
        
        

        try (PrintWriter out = response.getWriter()) {
            MyAppointment appointment = myAppointmentFacade.find(Long.parseLong(DeleteID));
            String slotID = appointment.getSlot();
            String vetID = appointment.getVetId();
            String date = appointment.getDate();
            
            
            
            // Retrieve all weekly rota entries for the given date
            List<WeeklyRota> weeklyRotas = weeklyRotaFacade.findAll();
           // boolean s = false;
            // Filter the weekly rota entries based on slotID and vetID
            WeeklyRota foundWeeklyRota = null;
            for (WeeklyRota weeklyRota : weeklyRotas) {
                if (weeklyRota.getId().equals(date)){
                    if (slotID.equals("Slot 1") && weeklyRota.getSlot1().equals(vetID)){
                        String a = weeklyRota.getAvailable1();
                        weeklyRota.setAvailable1("Available");
                        foundWeeklyRota = weeklyRota;
                        weeklyRotaFacade.edit(weeklyRota);
                        //out.println("<script>alert('1 ');</script>");
                        break;
                        
                    }
                    if (slotID.equals("Slot 2")&& weeklyRota.getSlot2().equals(vetID)){
                        String a = weeklyRota.getAvailable2();
                        weeklyRota.setAvailable2("Available");
                        foundWeeklyRota = weeklyRota;
                        weeklyRotaFacade.edit(weeklyRota);
                       // out.println("<script>alert('2 "+a+"');</script>");
                        break;
                        
                    }
                    if (slotID.equals("Slot 3")&& weeklyRota.getSlot3().equals(vetID)){
                        
                        weeklyRota.setAvailable3("Available");
                        foundWeeklyRota = weeklyRota;
                        weeklyRotaFacade.edit(weeklyRota);
                        //out.println("<script>alert('3');</script>");
                        break;
                        
                    }
                    if (slotID.equals("Slot 4")&& weeklyRota.getSlot4().equals(vetID)){
                        
                        weeklyRota.setAvailable4("Available");
                        foundWeeklyRota = weeklyRota;
                        weeklyRotaFacade.edit(weeklyRota);
                       //out.println("<script>alert('4');</script>");
                        break;
                        
                    }
                    if (slotID.equals("Slot 5")&& weeklyRota.getSlot5().equals(vetID)){
                        
                        weeklyRota.setAvailable5("Available");
                        foundWeeklyRota = weeklyRota;
                        weeklyRotaFacade.edit(weeklyRota);
                        //out.println("<script>alert('5');</script>");
                        break;
                        
                    }
                    if (slotID.equals("Slot 6")&& weeklyRota.getSlot6().equals(vetID)){
                        
                        weeklyRota.setAvailable6("Available");
                        foundWeeklyRota = weeklyRota;
                        weeklyRotaFacade.edit(weeklyRota);
                        //out.println("<script>alert('6');</script>");
                        break;
                        
                    }
                }
                
               
            }
            
            if (foundWeeklyRota != null) {
//                // Appointment found in weekly rota, you can proceed with deletion logic
//                // Example: weeklyRotaFacade.remove(foundWeeklyRota);
//                // Remove the appointment from the weekly rota
//                
//                // Remove the appointment from MyAppointmentFacade
                myAppointmentFacade.remove(appointment);
                
                out.println("<script>alert('Appointment deleted successfully');</script>");
                request.getRequestDispatcher("makeAppointment.jsp").include(request, response);
            } else {
                out.println("<script>alert('Appointment not found in the weekly rota');</script>");
                request.getRequestDispatcher("receptionistDashboard.jsp").include(request, response);
            }

        }
        catch (Exception e) {
            out.println("<script>alert('Sorry, Try Again. User not found.');</script>");
                request.getRequestDispatcher("receptionistDashboard.jsp").include(request, response);
                
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
