/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import Model.MyAppointment;
import Model.MyAppointmentFacade;
import Model.MyPet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Lashvin
 */
@WebServlet(name = "viewAppointmentReport", urlPatterns = {"/viewAppointmentReport"})
public class viewAppointmentReport extends HttpServlet {

    @EJB
    private MyAppointmentFacade myAppointmentFacade;

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            List<MyAppointment> appointments = myAppointmentFacade.findAll(); // Assuming this method exists to fetch all appointments

            // Check if appointments list is not empty
            if (!appointments.isEmpty()) {
                List<MyAppointment> userAppointments = new ArrayList<>(); // Initialize a list to store user's appointments

                // Iterate through the list to find the appointments with the matching vetId
                for (MyAppointment appointment : appointments) {
                    if (appointment.getVetId().equals(request.getSession().getAttribute("user"))) {
                        // Add the appointment to the user's appointments list
                        userAppointments.add(appointment);
                    }
                }

                // Check if user has any appointments
                if (!userAppointments.isEmpty()) {
                    // Set user's appointments list as an attribute in the session
                    request.getSession().setAttribute("userAppointments", userAppointments);
                    response.getWriter().println("<script>alert('Success');</script>");

                    // Forward to the viewAppointment.jsp page
                    request.getRequestDispatcher("viewAppointmentReport.jsp").forward(request, response);
                    return; // Exit the method after forwarding
                } else {
                    // Handle case where user has no appointments
                    response.getWriter().println("<script>alert('No appointments found for user " + request.getSession().getAttribute("user") + "');</script>");
                    request.getRequestDispatcher("vetDashboard.jsp").forward(request, response);
                }
            } else {
                // Handle case where appointments list is empty
                response.getWriter().println("<script>alert('No appointments found');</script>");
                request.getRequestDispatcher("vetDashboard.jsp").forward(request, response);
            }
        } catch (Exception e) {
            // Handle any exceptions
            response.getWriter().println("<script>alert('Error: " + request.getSession().getAttribute("user") + " " + e.getMessage() + "');</script>");
            request.getRequestDispatcher("vetDashboard.jsp").forward(request, response);
        }
    }


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
