/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Lashvin
 */
@Entity
public class WeeklyRota implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private String id;
    private String slot1;
    private String slot2;
    private String slot3;
    private String slot4;
    private String slot5;
    private String slot6;
    private String available1;
    private String available2;
    private String available3;
    private String available4;
    private String available5;
    private String available6;

    public String getSlot1() {
        return slot1;
    }

    public void setSlot1(String slot1) {
        this.slot1 = slot1;
    }

    public String getSlot2() {
        return slot2;
    }

    public void setSlot2(String slot2) {
        this.slot2 = slot2;
    }

    public String getSlot3() {
        return slot3;
    }

    public void setSlot3(String slot3) {
        this.slot3 = slot3;
    }

    public String getSlot4() {
        return slot4;
    }

    public void setSlot4(String slot4) {
        this.slot4 = slot4;
    }

    public String getSlot5() {
        return slot5;
    }

    public void setSlot5(String slot5) {
        this.slot5 = slot5;
    }

    public String getSlot6() {
        return slot6;
    }

    public void setSlot6(String slot6) {
        this.slot6 = slot6;
    }

    public String getAvailable1() {
        return available1;
    }

    public void setAvailable1(String available1) {
        this.available1 = available1;
    }

    public String getAvailable2() {
        return available2;
    }

    public void setAvailable2(String available2) {
        this.available2 = available2;
    }

    public String getAvailable3() {
        return available3;
    }

    public void setAvailable3(String available3) {
        this.available3 = available3;
    }

    public String getAvailable4() {
        return available4;
    }

    public void setAvailable4(String available4) {
        this.available4 = available4;
    }

    public String getAvailable5() {
        return available5;
    }

    public void setAvailable5(String available5) {
        this.available5 = available5;
    }

    public String getAvailable6() {
        return available6;
    }

    public void setAvailable6(String available6) {
        this.available6 = available6;
    }

    public WeeklyRota() {
    }

    public WeeklyRota(String id, String slot1, String slot2, String slot3, String slot4, String slot5, String slot6, String available1, String available2, String available3, String available4, String available5, String available6) {
        this.id = id;
        this.slot1 = slot1;
        this.slot2 = slot2;
        this.slot3 = slot3;
        this.slot4 = slot4;
        this.slot5 = slot5;
        this.slot6 = slot6;
        this.available1 = available1;
        this.available2 = available2;
        this.available3 = available3;
        this.available4 = available4;
        this.available5 = available5;
        this.available6 = available6;
    }
    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof WeeklyRota)) {
            return false;
        }
        WeeklyRota other = (WeeklyRota) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.WeeklyRota[ id=" + id + " ]";
    }

    public void setDate(Date date) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
